from EchoClient import EchoClientFactory
from twisted.internet import reactor
from data import Data

if __name__ == "__main__":
    #rx_ip = "192.168.100.18"
    #rx_port = "4000"
    #tx_ip = "192.168.100.18"
    #tx_port = "4001"
    rx_ip = "192.168.149.189"
    rx_port = "4301"
    tx_ip = "192.168.149.189"
    tx_port = "4501"

    datas = Data(tx_ip,tx_port)
    datas.updata()

    reactor.connectTCP(rx_ip, int(rx_port), EchoClientFactory(datas))
    reactor.run()