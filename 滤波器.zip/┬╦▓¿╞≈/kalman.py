import numpy as np


class KalmanFilter:
    def __init__(self, init_data, Q, R):
        self.N = init_data.shape[0]
        self.Q = Q
        self.R = R
        self.K = np.zeros(self.N)
        self.last_X = init_data
        self.new_X = init_data
        self.last_P = np.ones(self.N) * 0.01
        self.new_P = np.ones(self.N) * 0.01
        self.distance = np.zeros(self.N)
        self.weight = np.zeros(self.N)
        self.change = np.zeros(self.N)
        self.last_data = init_data  # 距离滤波器使用的上次的值
        self.re = np.zeros(self.N)

    def distance_weight_filter(self, data):
        self.distance = abs(data - self.last_data)
        self.weight = 2 - 2 / (1 + 10 ** (-10 * self.distance))
        self.change = self.weight * self.distance

        for i in range(self.N):
            if data[i] > self.last_data[i]:
                self.re[i] = self.last_data[i] + self.change[i]
            elif data[i] < self.last_data[i]:
                self.re[i] = self.last_data[i] - self.change[i]
            else:
                self.re[i] = self.last_data[i]
        self.last_data = self.re
        return self.re

    def kalman_filter_run(self, data):
        data = self.distance_weight_filter(data)
        self.K = self.last_P / (self.last_P + self.R) #计算卡尔曼增益
        self.new_X = self.last_X + self.K * (data - self.last_X) #进行校正更新
        self.last_X = self.new_X
        self.new_P = self.last_P - self.K * self.last_P + self.Q #更新P值
        self.last_P = self.new_P
        return self.new_X
