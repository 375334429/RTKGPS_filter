import socket
import threading
import numpy as np
import random
class Data():
    def __init__(self,tx_ip,tx_port):
        self.data_num = 0
        self.histry_data = np.zeros((3, 7200), dtype=np.float)
        self.histry_tx_buf = None
        self.tx_ip = tx_ip
        self.tx_port = tx_port
        self.mini_data0 = '1'
        self.mini_data1 = '20'
        self.mini_data2 = '0.0004'
        self.mini_data3 = '0.00'
        self.mini_data4 = '1.1'
        self.mini_data5 = '2019/07/29'
        self.mini_data6 = '08:00:56.000'

    def save_data(self, x, y, z):
        self.histry_data[0, self.data_num] = x
        self.histry_data[1, self.data_num] = y
        self.histry_data[2, self.data_num] = z
        self.data_num += 1

    def updata(self):
        threading.Timer(60 * 60, self.updata).start()
        tx_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tx_socket.connect((self.tx_ip, int(self.tx_port)))
        if self.data_num > 100:
            self.sum_data = self.histry_data.sum(1)  # 求和
            self.mean_x = round(
                self.sum_data[0] / self.data_num * 10000 ) / 10000  # 求平均
            self.mean_y = round(
                self.sum_data[1] / self.data_num * 10000 ) / 10000
            self.mean_z = round(
                self.sum_data[2] / self.data_num * 10000 ) / 10000
            #random.randint(-10, 10)
            tx_buf = self.mini_data5 + ' ' + self.mini_data6 + str(self.mean_x).rjust(15) + str(self.mean_y).rjust(15) + str(self.mean_z).rjust(15) + self.mini_data0.rjust(
                4) + self.mini_data1.rjust(4) + self.mini_data2.rjust(
                9) + self.mini_data2.rjust(9) + self.mini_data2.rjust(9) + self.mini_data2.rjust(9) + self.mini_data2.rjust(9) + self.mini_data2.rjust(9) + \
                     self.mini_data3.rjust(7) + self.mini_data4.rjust(7) + "\n"
            tx_socket.send(bytes(tx_buf, encoding="utf8"))
            print(tx_buf)
            self.data_num = 0
            self.histry_data = np.zeros((3, 7200), dtype=np.float)
            self.histry_tx_buf = tx_buf
        else:
            if self.histry_tx_buf:
                tx_socket.send(bytes(self.histry_tx_buf, encoding="utf8"))
                print(self.histry_tx_buf)
                print('数据量不足')
        tx_socket.close()