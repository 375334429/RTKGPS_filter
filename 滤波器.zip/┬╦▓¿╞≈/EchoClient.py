from twisted.internet.protocol import Protocol, ReconnectingClientFactory
import numpy as np
import kalman

class Echo(Protocol):
    def __init__(self,datas):
        self.i=0
        self.datas=datas


    def dataReceived(self, data):
        print(data)
        data = str(data).split()
        if len(data) >= 15 and int(data[5]) == 1:
            data[0] = data[0][2:]
            data[14] = data[14][:-3]
            if self.i == 0:
                init_data = np.array(
                    [float(data[2]), float(data[3]), float(data[4])])
                Q = np.array([0.000001, 0.000001, 0.000001])
                R = np.array([0.1, 0.1, 0.1])
                self.kalman_users = kalman.KalmanFilter(init_data, Q, R)
            else:
                filter_data = np.array(
                    [float(data[2]), float(data[3]), float(data[4])])
                filter_data = self.kalman_users.kalman_filter_run(filter_data)
                self.datas.save_data(
                    filter_data[0], filter_data[1], filter_data[2])
            self.i = self.i + 1


class EchoClientFactory(ReconnectingClientFactory):
    def __init__(self,datas):
        self.datas = datas

    def startedConnecting(self, connector):
        print('Started to connect.')

    def buildProtocol(self, addr):
        print('Connected.')
        self.resetDelay()
        return Echo(self.datas)

    def clientConnectionLost(self, connector, reason):
        print('Lost connection.  Reason:', reason)
        ReconnectingClientFactory.clientConnectionLost(self, connector, reason)
        if self.delay > 60 :
            self.delay = 60

    def clientConnectionFailed(self, connector, reason):
        print('Connection failed. Reason:', reason)
        ReconnectingClientFactory.clientConnectionFailed(self, connector,
                                                         reason)
        if self.delay > 60 :
            self.delay = 60